#! usr/bin/python3
import cards_tools
#无限循环，由用户进行操作是否结束循环
while True:
    #TODO（Mr_Liang） 显示功能菜单 这种注释可以及时提醒我们
    cards_tools.show_menu()
    action_str =input("请输入希望执行的操作")
    print("您执行的操作为【%s】"%action_str)
    if action_str in ["1","2","3"]:
        #新增名片
        if action_str =="1":
            cards_tools.new_card()
        #显示全部
        elif action_str =="2":
            cards_tools.show_all()
        #查询名片
        elif action_str =="3":
            cards_tools.search_card()
    elif action_str in ["0"]:
    # elif action_str =="0":
        print("欢迎再次使用【名片管理系统】！")
        break
    else:
        print("输入错误！")
#针对于字符串判断通过in来进行解决 if action in ["1","2","3"]:
# 同样也可以使用这个语句来进行判断if action =="1 or action=="2" or action =="3"
#注意：我们这里千万不要用int来进行接收，如果不是int型那么就会报错，导致程序无法执行